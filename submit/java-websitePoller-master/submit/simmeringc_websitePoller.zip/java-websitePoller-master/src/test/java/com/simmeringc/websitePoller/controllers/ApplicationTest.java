/**
 * Created by Conner on 4/30/17.
 */

package com.simmeringc.websitePoller.controllers;

public class ApplicationTest {

}
